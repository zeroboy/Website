<?php
return array(
	//'配置项'=>'配置值'
		//数据库配置信息
        'DB_TYPE'   => 'mysql', // 数据库类型
        'DB_HOST'   => '101.200.190.17', // 服务器地址
        'DB_NAME'   => 'bdm108519251_db', // 数据库名
        'DB_USER'   => 'zeroboy', // 用户名
        'DB_PWD'    => '2514782544sbsyg', // 密码
        'DB_PORT'   => 3306, // 端口
        'DB_PREFIX' => 'blog_', // 数据库表前缀 

	//默认Home
		'DEFAULT_MODULE'  =>  'Home',
		'MODULE_ALLOW_LIST'    =>    array('Home'),

	//模板定界符
		'TMPL_L_DELIM'=>'<!--{',
		'TMPL_R_DELIM'=>'}-->',

		"PAGESIZE"=>10,
		"UPLOAD_PATH"=>__ROOT__."/Uploads/",//上传路径
		
	// 定义公共错误模板
	//'TMPL_EXCEPTION_FILE'=>'Public/Home/tpl/404.html',

	//'ERROR_PAGE'=>'Public/Home/tpl/404.html',

	//'TMPL_ACTION_ERROR' => 'Public/Home/tpl/error.html',

	//文章评论前缀
	"ARTICLE_THREAD_KEY"=>"article_key_",
);
