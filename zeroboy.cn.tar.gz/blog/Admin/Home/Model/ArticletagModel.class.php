<?php
// +----------------------------------------------------------------------
// |  Author: MrZero
// +----------------------------------------------------------------------
// |  QQ : 2586073409
// +----------------------------------------------------------------------
// | Motto: People just walking shadow
// +----------------------------------------------------------------------
// | model: 
// +----------------------------------------------------------------------

namespace Home\Model;
use Think\Model;

class ArticleTagModel extends Model{

	
	protected $_map = array(	
		'tagname'=>'tag_name',//名称
		//'tagid'=>'tag_id',//id
	);

	protected $_validate = array(

		array('tag_name','require','标签名称必填！'),
	);


}
?>