<?php
// +----------------------------------------------------------------------
// |  Author: MrZero
// +----------------------------------------------------------------------
// |  QQ : 2586073409
// +----------------------------------------------------------------------
// | Motto: People just walking shadow
// +----------------------------------------------------------------------
// | model: 上传
// +----------------------------------------------------------------------


namespace Home\Controller;
use Think\Controller;

class ImgUploadController extends BaseController {

	public function ArticleFace(){
		
		$data = array(
			"statusCode"=>"200",
			"message"=>"上传成功！",
			"filename"=>"images/bjui-b.png"	,
			"request"=>$_REQUEST,
		);

		$this->ajaxReturn($data);
	}
}


?>