<?php
/**
 * People Just Walking Dead.
 * 
 * @author  ZeroBoy 
 * @version 1.0
 * @model ҳüҳ��
 */

namespace Home\Controller;
use Think\Controller;
class HeaderController extends BaseController {

	public 
	/**
	 * չʾ.
	 * @param   type    $varname    description
	 * @return  type    description
	 * @access  public or private
	 * @static  makes the class property accessible without needing an instantiation of the class
	 */
	function index()
	{
	
		$this->display();
	} // end func
}
?>