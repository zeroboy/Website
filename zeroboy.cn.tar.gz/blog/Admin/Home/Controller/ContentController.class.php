<?php
/**
 * People Just Walking Dead.
 * 
 * @author  ZeroBoy 
 * @version 1.0
 * @model ������
 */

namespace Home\Controller;
use Think\Controller;
class ContentController extends BaseController {

	public 
	/**
	 * չʾ.
	 */
	function index()
	{
	  $this->display();  
	} // end func
}

?>