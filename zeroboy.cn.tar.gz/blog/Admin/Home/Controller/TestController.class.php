<?php
namespace Home\Controller;
use Think\Controller;
class TestController extends Controller {

public function index(){

	$test = M("test");

	$res = $test->select();

	var_dump($res);
}


}