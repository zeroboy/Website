<?php
/**
 * People Just Walking Dead.
 * 
 * @author  ZeroBoy 
 * @version 1.0
 * @model 后台首页
 */
namespace Home\Controller;
use Think\Controller;
class IndexController extends BaseController {
    public function index(){
       
	   $this->display();
    }
}