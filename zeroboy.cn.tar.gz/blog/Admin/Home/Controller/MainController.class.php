<?php
/**
 * People Just Walking Dead.
 * 
 * @author  ZeroBoy 
 * @version 1.0
 * @model 菜单模块
 */

 namespace Home\Controller;
use Think\Controller;
class MainController extends BaseController {

	public 
	/**
	 * 展示.
	 */
	function index()
	{
	   $this->display(); 
	} // end func
}
?>