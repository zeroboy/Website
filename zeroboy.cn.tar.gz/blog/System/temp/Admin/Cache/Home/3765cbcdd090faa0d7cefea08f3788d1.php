<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <title>xxx</title>
 </head>
 <link rel="stylesheet" type="text/css" href="/blog/Public/Admin/css/common.css">
 <script type="text/javascript" src="/blog/Public/Admin/js/jquery-1.7.2.min.js"></script>
 <body>
 <div class="bjui-pageContent">

	<div class="smalldiv">

	<button type="button" class="btn btn-green" data-toggle="dialog" data-id="ArticleAdd" data-url="<?php echo U('Articlemsgtype/AddShow','',false);?>" data-title="添加新文章模板分类" data-options="{width:'900',height:'450'}">添加新文章模板分类</button>

	</div>

		</div>
		<div class="bjui-pageFooter">
			<ul>
				<li><button type="button" class="btn-close" data-icon="close">关闭</button></li>
			</ul>
		</div>
	</body>
</html>