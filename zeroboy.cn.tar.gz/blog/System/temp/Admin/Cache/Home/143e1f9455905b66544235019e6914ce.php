<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <title>xxx</title>
 </head>
 <link rel="stylesheet" type="text/css" href="/blog/Public/Admin/css/common.css">
 <script type="text/javascript" src="/blog/Public/Admin/js/jquery-1.7.2.min.js"></script>
 <body>
 <div class="bjui-pageContent">
<div class="smalldiv">
	<button type="button" class="btn btn-green" data-toggle="dialog" data-url="<?php echo U('System/UpdateShow','',false);?>"data-options="{id:'SystemUpdate',title:'修改配置参数',width:'900',height:'400'}">修改配置参数</button>
</div>
	<table class='table table-bordered table-striped table-hover'>
	<tbody>
				<tr>
					<td>数据库类型</td>
					<td><?php echo ($sys_config['DB_TYPE']); ?></td>
				</tr>
				<tr>
					<td>数据库主机</td>
					<td><?php echo ($sys_config['DB_HOST']); ?></td>					
				</tr>
				<tr>
					<td>数据库名称</td>
					<td><?php echo ($sys_config['DB_NAME']); ?></td>
				</tr>
				<tr>
					<td>数据库端口</td>
					<td><?php echo ($sys_config['DB_PORT']); ?></td>
				</tr>
				<tr>
					<td>数据表前缀</td>
					<td><?php echo ($sys_config['DB_PREFIX']); ?></td>
				</tr>
				<tr>
					<td>模板右标签</td>
					<td><?php echo ($sys_config['TMPL_R_DELIM']); ?></td>
				</tr>
				<tr>
					<td>模板左标签</td>
					<td><?php echo ($sys_config["TMPL_L_DELIM"]); ?></td>
				</tr>
		</tbody>
	</table>
		</div>
		<div class="bjui-pageFooter">
			<ul>
				<li><button type="button" class="btn-close" data-icon="close">关闭</button></li>
			</ul>
		</div>
	</body>
</html>