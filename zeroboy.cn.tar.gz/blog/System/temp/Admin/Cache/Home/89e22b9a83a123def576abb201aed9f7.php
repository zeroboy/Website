<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <title>xxx</title>
 </head>
 <link rel="stylesheet" type="text/css" href="/blog/Public/Admin/css/common.css">
 <script type="text/javascript" src="/blog/Public/Admin/js/jquery-1.7.2.min.js"></script>
 <body>
 <div class="bjui-pageContent">
	<form  action="<?php echo U('System/DoUpdate','',false);?>" data-toggle="validate">
	<table class='table table-bordered table-striped table-hover'>	
		<tbody>
				<tr>
					<td>数据库类型</td>
					<td><input type="text" name="DB_TYPE" value="<?php echo ($sys_config['DB_TYPE']); ?>" data-rule="数据库类型:required;" disabled></td>
				</tr>
				<tr>
					<td>数据库主机</td>
					<td><input type="text" name="DB_HOST" value="<?php echo ($sys_config['DB_HOST']); ?>" data-rule="数据库主机:required;"></td>					
				</tr>
				<tr>
					<td>数据库名称</td>
					<td><input type="text" name="DB_NAME" value="<?php echo ($sys_config['DB_NAME']); ?>" data-rule="数据库名称:required;"></td>
				</tr>
				<tr>
					<td>数据库端口</td>
					<td><input type="text" name="DB_PORT" value="<?php echo ($sys_config['DB_PORT']); ?>" data-rule="数据库端口:required;"></td>
				</tr>
				<tr>
					<td>数据表前缀</td>
					<td><input type="text" name="DB_PREFIX" value="<?php echo ($sys_config['DB_PREFIX']); ?>" data-rule="数据表前缀:required;"></td>
				</tr>
				<tr>
					<td>模板右标签</td>
					<td><input type="text" name="TMPL_R_DELIM" value="<?php echo ($sys_config['TMPL_R_DELIM']); ?>" disabled data-rule="模板右标签:required;"></td>
				</tr>
				<tr>
					<td>模板左标签</td>
					<td><input type="text" name="TMPL_L_DELIM" value="<?php echo ($sys_config['TMPL_L_DELIM']); ?>" disabled data-rule="模板左标签:required;"></td>
				</tr>
				<tr>
					<td colspan=2>
					<p class="text-center"><button type="submit" class="btn btn-default">确认修改</button></p>
					</td>
				</tr>
		</tbody>
	</table>
</form>				
		</div>
		<div class="bjui-pageFooter">
			<ul>
				<li><button type="button" class="btn-close" data-icon="close">关闭</button></li>
			</ul>
		</div>
	</body>
</html>