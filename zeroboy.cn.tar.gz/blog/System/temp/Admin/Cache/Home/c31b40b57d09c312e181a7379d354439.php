<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <title>xxx</title>
 </head>
 <link rel="stylesheet" type="text/css" href="/blog/Public/Admin/css/common.css">
 <script type="text/javascript" src="/blog/Public/Admin/js/jquery-1.7.2.min.js"></script>
 <body>
 <div class="bjui-pageContent">

<script src="/blog/Public/Admin/js/uploadify/jquery.uploadify.min.js" type="text/javascript"></script>

<link rel="stylesheet" type="text/css" href="/blog/Public/Admin/css/uploadify/uploadify.css">

<!--{<?php if($ArticleList): ?>}-->

	<form action="<?php echo U('Article/DoUpdate','',false);?>" data-toggle="validate" id="articleform">

<!--{<?php else: ?>}-->

	<form action="<?php echo U('Article/DoAdd','',false);?>" data-toggle="validate" id="articleform">

<!--{<?php endif; ?>}-->

		<table class="table table-bordered table-striped table-hover">

		<tbody>

			<tr>

				<td>文章分类</td>

				<td>

				<select name="article_cate" data-toggle="selectpicker" >

					<!--{<?php if(is_array($ArticleCateList)): foreach($ArticleCateList as $key=>$vo): ?>}-->

						<!--{<?php if(($vo["articlecate_id"]) == $ArticleList['article_cate_id_code']): ?>}-->

							<option value="<?php echo ($vo["articlecate_id"]); ?>" selected>

						<!--{<?php else: ?>}-->

							<option value="<?php echo ($vo["articlecate_id"]); ?>">

						<!--{<?php endif; ?>}-->

						<?php echo ($vo["html"]); echo ($vo["articlecate_name"]); ?>

						</option>

					<!--{<?php endforeach; endif; ?>}-->

				</select>

				</td>

			</tr>

			<tr>
					<td>文章类型</td>
					<td>
						<select name="article_type" data-toggle="selectpicker">
							<!--{<?php if($ArticleList['article_type'] == 1): ?>}-->
								<option value="1" selected>原创</option>
							<!--{<?php else: ?>}-->
								<option value="1" >原创</option>
							<!--{<?php endif; ?>}-->
							<!--{<?php if($ArticleList['article_type'] == 2): ?>}-->
								<option value="2" selected>转载</option>
							<!--{<?php else: ?>}-->
								<option value="2" >转载</option>
							<!--{<?php endif; ?>}-->
						</select>
					</td>	
			</tr>
			<tr>

				<td>文章标题</td>

				<td>

				<input type="text" class="form-control" name="article_title" value="<?php echo ($ArticleList['article_title']); ?>" data-rule="文章标题:required;length[4~];" placeholder="文章标题"  data-msg-digits="文章标题不能使用纯数字" >

				</td>

			</tr>

			<tr>

			<td>文章内容</td>

			<td>

				<div style="display: inline-block; vertical-align: middle;">

					<textarea name="article_content" id="j_form_content" class="j-content" style="width: 700px;" data-toggle="kindeditor" data-minheight="200" data-rule="文章内容:required;<?php echo C('Article_Rule2');?>">

						<?php echo ($ArticleList['article_content']); ?>

					</textarea>

				</div>

			</td>

            </tr>



			<tr>

				<td>是否开启评论</td>

				<td>

				<select name="article_comment" data-toggle="selectpicker" data-style="btn-success" onchange='abc(this)'>



					<!--{<?php if($ArticleList['article_is_comment'] ): ?>}-->

						<!--{<?php if($ArticleList['article_is_comment'] == 1): ?>}-->

						<option value="1" selected>是</option>

						<option value="0">否</option>

						<!--{<?php else: ?>}-->

						<option value="0" selected>否</option>

						<option value="1">是</option>

						<!--{<?php endif; ?>}-->

					<!--{<?php else: ?>}-->

						<option value="0" selected>否</option>

						<option value="1">是</option>

					<!--{<?php endif; ?>}-->



				</select>

				</td>

			</tr>

			<!--{<?php if(($ArticleList['article_is_comment'] == 1 )&& ($ArticleList['article_max_communicate_count'])): ?>}-->

			<tr id="max_communicate">

			<td>评论限制量</td>

					<td>

						<input type="text" class="form-control" name="max_commcount" value="<?php echo ($ArticleList['article_max_communicate_count']); ?>" data-rule="评论限制量:integer[+];" placeholder="评论限制量"  data-msg-digits="评论限制量不能为非数字" >

					</td>

			</tr>

			<!--{<?php else: ?>}-->

			<tr id="max_communicate" style="display:none;">

			<td>评论限制量</td>

					<td>

						<input type="text" class="form-control" name="max_commcount" value="<?php echo ($ArticleList['article_max_communicate_count']); ?>" placeholder="评论限制量"  data-msg-digits="评论限制量不能为非数字" >

					</td>

			</tr>

			<!--{<?php endif; ?>}-->

					

			<tr>

					<td>文章封面</td>

					<td>

							<input id="file_upload" name="file_upload" type="file" multiple="true" value="上传头像" >

					</td>

			</tr>

			<tr>

						<td>文章标签</td>

						<td>

							<select name="tagselect" data-toggle="selectpicker" multiple data-width="300" onchange="tagget(this)">

							<!--{<?php if(is_array($ArticleTagData)): foreach($ArticleTagData as $key=>$vo): ?>}-->

							<!--{<?php if(in_array(($vo["tag_id"]), is_array($ArticleList['article_tags'])?$ArticleList['article_tags']:explode(',',$ArticleList['article_tags']))): ?>}-->

								<option value="<?php echo ($vo["tag_id"]); ?>" selected><?php echo ($vo["tag_name"]); ?></option>

							<!--{<?php else: ?>}-->

								<option value="<?php echo ($vo["tag_id"]); ?>"><?php echo ($vo["tag_name"]); ?></option>

							<!--{<?php endif; ?>}-->

							<!--{<?php endforeach; endif; ?>}-->

							</select>

							<input type="hidden" name="tagstring" value="<?php echo ($ArticleList['article_tags']); ?>">

						</td>		

			<tr>

			<!--{<?php if($ArticleList): ?>}-->

				<input type="hidden" name="article_id" value="<?php echo ($ArticleList['article_id']); ?>">

				<td colspan="2"><p class="text-center"><button type="submit" class="btn btn-default">修改文章</button></p></td>

			<!--{<?php else: ?>}-->

				<td colspan="2"><p class="text-center"><button type="submit" class="btn btn-default">添加文章</button></p></td>

			<!--{<?php endif; ?>}-->			

			</tr>

		</tbody>

		</table>

	</form>

	<div id="abc123" class="">

		

	</div>

	<input type="hidden" name="sname" value="<?php echo ($sname); ?>">

	<input type="hidden" name="sid" value="<?php echo ($sid); ?>">

		</div>
		<div class="bjui-pageFooter">
			<ul>
				<li><button type="button" class="btn-close" data-icon="close">关闭</button></li>
			</ul>
		</div>
	</body>
</html>





<script type="text/javascript">



/*

$(function(){



	$("select[name=article_iscomment]").click(function(){

	

		if($(this).val() == '1'){

			$("#max_communicate").show();

		}else{

			$("#max_communicate").hide();

		}



		console.log($(this).val());

	});

})

*/



function abc(obj){



	if(obj.value == '1'){

			$("#max_communicate").show();

			//obj.setAttribute("data-style","btn-success");

			

		}else{

			$("#max_communicate").hide();

			$("input[name=max_commcount]").val('');

			//obj.setAttribute("data-style","btn-dangor");



	}

}











		$(function() {



			_articledata = "<?php echo ($ArticleList['article_face_path']); ?>";

			var buttontext = (_articledata)?_articledata:"上传封面"; //文本

			var _width = (_articledata)?550:120;

			var _id = "<?php echo ($ArticleList['article_id']); ?>";

			var _sessionname = $("input[name=sname]").val();

			var _sessionid = $("input[name=sid]").val();

			_url = "<?php echo U('Uploadify/upload','',false);?>";

			$('#file_upload').uploadify({

				'buttonClass' : 'some-class',

				//'auto':false,

				'buttonText' : buttontext,  //按钮文本

				//'buttonImage' : '/blog/Public/Admin/image/uploadify/browse-btn.png', //按钮背景图片

				'formData'     : {

					'id' : _id,

					"authid" : _sessionid,

				},

				'swf'      : '/blog/Public/Admin/image/uploadify/uploadify.swf',

				'uploader' : _url, //文件上传处理

				'height'       :34,

				'width'		: _width,

				//'checkExisting' : 'check-exists.php',//验证同名文件是否已经存在

				'onUploadSuccess' : function(file, data, response) {

					//console.log(String(data));

//return;

					var datas = eval('(' +data+')');

					console.log(datas);

					console.log(datas.status);

					console.log(datas.status>0);

					if(datas.status>0){

						//alert('这个文件 ' + file.name + '已经成功被上传 ' + response + ':' + datas.content);

						var jsonstr = "{msg:'文件:"+datas.content.Filedata.name+" 已经被成功上传', type:'ok'}";

						var msgstr = '<button type="button" class="btn-default" data-toggle="alertmsg" data-options="'+jsonstr+'" id="infomsg" style="display:none;"></button>';

						$("#abc123").html(msgstr);

						//$('#infomsg').attr("data-options",jsonstr)

						$('#infomsg').trigger("click");



					}else{

						//alert('文件 ' + file.name + '上传失败~ 原因:' + datas.msg);

						var jsonstr = "{msg:'"+datas.msg+"', type:'error'}";

						var msgstr = '<button type="button" class="btn-default" data-toggle="alertmsg" data-options="'+jsonstr+'" id="infomsg" style="display:none;"></button>';

						$("#abc123").html(msgstr);

						//$('#infomsg').attr("data-options",jsonstr)

						$('#infomsg').trigger("click");



					}

						

				},

				 'onUploadError' : function(file, errorCode, errorMsg, errorString) {

						alert('The file ' + file.name + ' could not be uploaded: ' + errorString);

				},

				'onCancel' : function(file) {

						alert('The file ' + file.name + ' was cancelled.');

				}

			});





			

			//$("#articleform").submit(function(){

			//$("#articleform").bjuiajax('ajaxForm', {

				//"confirmMsg":"是否确认提交？",

			//})



		});





		function tagget(obj){

			

			

			//console.log($("select[name=tagselect]").find("option:selected").length);

			var str = '';

			$("select[name=tagselect]").find("option:selected").each(function(){

			

					str += $(this).val()+",";

			});



			console.log(str);

			$("input[name=tagstring]").val(str);



		}



</script>