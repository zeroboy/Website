<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <title>Content</title>
 </head>
 <body style="background:rgb(255,255,204);">
  <h3>This is Content</h3>
 </body>
</html>