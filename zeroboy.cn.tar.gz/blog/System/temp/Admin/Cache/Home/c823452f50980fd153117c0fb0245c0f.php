<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <title>xxx</title>
 </head>
 <link rel="stylesheet" type="text/css" href="/blog/Public/Admin/css/common.css">
 <script type="text/javascript" src="/blog/Public/Admin/js/jquery-1.7.2.min.js"></script>
 <body>
 <div class="bjui-pageContent">
	<!--{<?php if($taginfo != null): ?>}-->
	<form action="<?php echo U('Tag/DoUpdate','',false);?>" data-toggle="validate">
	<table class='table table-bordered table-striped table-hover'>
		<tr>
			<td>标签名称</td>
			<td>
				<input class="form-control" name="tagname" data-rule="required;" placeholder="标签名称" type="text" value="<?php echo ($taginfo['tag_name']); ?>">
				<input type="hidden" name="tagid" value="<?php echo ($taginfo['tag_id']); ?>">	
			</td>
		</tr>
		<tr>
			<td colspan='2'>
				<p class="text-center"><button type="submit" class="btn btn-default">修改分组</button></p>
			</td>
		</tr>
	</table>		
	</form>
	<!--{<?php else: ?>}-->
	<form action="<?php echo U('Tag/DoAdd','',false);?>" data-toggle="validate">
		<table class='table table-bordered table-striped table-hover'>
				<tr>
					<td>标签名称</td>
					<td>
						<input class="form-control" name="tagname" data-rule="required;" placeholder="标签名称" type="text" value="">
					</td>
				</tr>
				<tr>
					<td colspan='2'>
						<p class="text-center"><button type="submit" class="btn btn-default">添加分组</button></p>
					</td>
				</tr>
		</table>

		</form>
	<!--{<?php endif; ?>}-->

 </body>
</html>