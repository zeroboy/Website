<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <title></title>
 </head>
 <body>

		<header id="bjui-header">
			<!-- logo -->
			<a class="bjui-navbar-logo" href="http://www.zeroboy.cn" target="_blank"><img src="/blog/Public/Admin/image/mylogo.png" style="height:35px;"></a>
			<!-- 快捷菜单(消息、用户信息、切换皮肤) -->
        <nav id="bjui-navbar-collapse">
            <ul class="bjui-navbar-right">
                <li class="datetime"><div><span id="bjui-date"></span> <span id="bjui-clock"></span></div></li>

				<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">我的账户 <span class="caret"></span></a>
                    <ul class="dropdown-menu" role="menu">
                        <li><a href="javascript:;">&nbsp;<span class="glyphicon glyphicon-user"></span><?php echo ($_SESSION['userinfo']['user_account']); ?></a></li>
                        <li class="divider"></li>
                        <li><a href="javascript:;" onclick='window.parent.location="<?php echo U("Login/LoginOut","",false);?>";' class="red">&nbsp;<span class="glyphicon glyphicon-off"></span> 注销登陆</a></li>
                    </ul>
                </li>

				<li class="dropdown"><a href="#" class="dropdown-toggle theme blue" data-toggle="dropdown" title="切换皮肤"><i class="fa fa-tree"></i></a>
                    <ul class="dropdown-menu" role="menu" id="bjui-themes">
                        <li><a href="javascript:;" class="theme_default" data-toggle="theme" data-theme="default">&nbsp;<i class="fa fa-tree"></i> 黑白分明&nbsp;&nbsp;</a></li>
                        <li><a href="javascript:;" class="theme_orange" data-toggle="theme" data-theme="orange">&nbsp;<i class="fa fa-tree"></i> 橘子红了</a></li>
                        <li><a href="javascript:;" class="theme_purple" data-toggle="theme" data-theme="purple">&nbsp;<i class="fa fa-tree"></i> 紫罗兰</a></li>
                        <li class="active"><a href="javascript:;" class="theme_blue" data-toggle="theme" data-theme="blue">&nbsp;<i class="fa fa-tree"></i> 天空蓝</a></li>
                        <li><a href="javascript:;" class="theme_green" data-toggle="theme" data-theme="green">&nbsp;<i class="fa fa-tree"></i> 绿草如茵</a></li>
                    </ul>
                </li>

			</ul>
		</nav>
			<!-- 横向菜单 -->
					<div id="bjui-hnav">
						<ul id="bjui-hnav-navbar">
				<!-- zTree菜单 - BEGIN -->
				<!--data-id 表示 弹窗的不同-->
							<li class="active">
								<a href="javascript:;" data-toggle="slidebar"><i class="fa fa-check-square-o"></i> 首页</a>
								<div class="items hide" data-noinit="true">

									<ul class="menu-items" data-tit="首页" data-faicon="list">
										<li class="active switch">
											<a href="<?php echo U('Content/index','',false);?>" data-toggle="navtab" data-options="{id:'content',title:'首页',faicon:'caret-right'}" target="_blank">首页</a>
										</li>
									</ul>

								</div>
							</li>

							<li>
								<a href="javascript:;" data-toggle="slidebar"> 文章分组管理</a>
								<div class="items hide" data-noinit="true">

									<ul class="menu-items" data-tit="文章分组管理" data-faicon="list">
										<li class="active switch">
											<a href="<?php echo U('ArticleCategory/index','',false);?>" data-toggle="navtab" data-options="{id:'ArticleCategory',title:'文章分组管理',faicon:'caret-right'}" target="_blank">文章分组管理</a>
										</li>
								</div>
							</li>


							<li>
								<a href="javascript:;" data-toggle="slidebar"> 文章管理</a>
								<div class="items hide" data-noinit="true">

									<ul class="menu-items" data-tit="文章管理" data-faicon="list">
										<li class="active switch">
											<a href="<?php echo U('Article/index','',false);?>" data-toggle="navtab" data-options="{id:'Article',title:'文章管理',faicon:'caret-right'}" target="_blank">文章管理</a>
										</li>
										<li >
											<a href="<?php echo U('Tag/index','',false);?>" data-toggle="navtab" data-options="{id:'Tag',title:'文章标签管理',faicon:'caret-right'}" target="_blank">文章标签管理</a>
										</li>
									</ul>

								</div>
							</li>

							<li>
							    <a href="javascript:;" data-toggle="slidebar"> 评论管理</a>
								<div class="items hide" data-noinit="true">

								   <ul class="menu-items" data-tit="评论管理" data-faicon="list">
										<li class="active switch">
											<a href="<?php echo U('CommentManger/index','',false);?>" data-toggle="navtab" data-options="{id:'Comment',title:'评论管理',faicon:'caret-right'}" target="_blank">评论管理</a>
										</li>
									</ul>

								</div>
							</li>

							<li>
								<a href="javascript:;" data-toggle="slidebar">用户分组管理</a>
								<div class="items hide" data-noinit="true">

									<ul class="menu-items" data-tit="用户分组管理" data-faicon="list">
										<li class="active switch">
											<a href="<?php echo U('UserCategory/index','',false);?>" data-toggle="navtab" data-options="{id:'UserCategory',title:'用户分组管理',faicon:'caret-right'}" target="_blank">用户分组管理</a>
										</li>
									</ul>

								</div>
							</li>

							<li>
								<a href="javascript:;" data-toggle="slidebar"> 用户管理</a>
								<div class="items hide" data-noinit="true">

									<ul class="menu-items" data-tit="用户管理" data-faicon="list">
										<li class="active switch">
											<a href="<?php echo U('User/index','',false);?>" data-toggle="navtab" data-options="{id:'User',title:'用户管理',faicon:'caret-right'}" target="_blank">用户管理</a>
										</li>
									</ul>
								</div>
							</li>

							<li>
								<a href="javascript:;" data-toggle="slidebar"> 系统管理</a>
								<div class="items hide" data-noinit="true">

									<ul class="menu-items" data-tit="系统管理" data-faicon="list">
										<li  class="active switch">
											<a href="<?php echo U('System/index','',false);?>" data-toggle="navtab" data-options="{id:'System',title:'配置管理',faicon:'caret-right'}" target="_blank">配置管理</a>
										</li>
										<li >
											<a href="<?php echo U('OutService/index','',false);?>" data-toggle="navtab" data-options="{id:'System',title:'外部服务管理',faicon:'caret-right'}" target="_blank">外部服务管理</a>
										</li>
									</ul>
								</div>
							</li>

							<!-- 
							<li >
								<a href="javascript:;" data-toggle="slidebar"><i class="fa fa-check-square-o"></i> 测试2</a>
								<div class="items hide" data-noinit="true">
									<ul class="menu-items" data-tit="测试demo2" data-faicon="list">
										<li>
											<a href="" data-toggle="navtab" data-options="{id:'test6',title:'测试index6',faicon:'caret-right'}" target="_blank">测试index6</a>
										</li>
										<li>
											<a href="" data-toggle="navtab" data-options="{id:'test7',title:'测试index7',faicon:'caret-right'}" target="_blank">测试index7</a>
										</li>
									</ul>
								</div>
							</li>
							 -->

				<!-- zTree菜单 - END -->
						</ul>

					</div>
			<!-- 横向菜单 -->
		</header>

		<div id="bjui-container" class="clearfix" >
			<!-- 导航栏 -->
			<div id="bjui-leftside">
				<div id="bjui-sidebar">
					<div class="toggleCollapse"><h2><i class="fa fa-bars"></i> 导航栏 <i class="fa fa-bars"></i></h2><a href="javascript:;" class="lock"><i class="fa fa-lock"></i></a></div>
					<div class="panel-group panel-main" data-toggle="accordion" id="bjui-accordionmenu">
					</div>
				</div>
			</div>
			<!-- 导航栏 -->

			<!-- 工作区(navtab) -->
				<div id="bjui-navtab" class="tabsPage">
					<div class="tabsPageHeader">
						<div class="tabsPageHeaderContent">
							<ul class="navtab-tab nav nav-tabs">
								<li data-url="<?php echo U('Content/index','',false);?>" data-faicon="home"><a href="javascript:;"><span><i class="fa fa-home"></i> #maintab#</span></a></li>
							</ul>
						</div>
						<div class="tabsLeft"><i class="fa fa-angle-double-left"></i></div>
						<div class="tabsRight"><i class="fa fa-angle-double-right"></i></div>
						<div class="tabsMore"><i class="fa fa-angle-double-down"></i></div>
					</div>
					<ul class="tabsMoreList">
						<li><a href="javascript:;">#maintab#</a></li>
					</ul>
					<div class="navtab-panel tabsPageContent" style="height: 332px;">
						<div class="navtabPage unitBox" >
							<div class="bjui-pageContent" style="background:#FFF;">
								Loading...
							</div>
						</div>
					</div>
				</div>
			<!-- 工作区(navtab) -->

		</div>

		<!-- 页脚 -->
		<footer id="bjui-footer">
		
		</footer>
		<!-- 页脚 -->


 </body>
</html>



<link href="/blog/Public/Admin/js/BJUI/themes/css/bootstrap.css" rel="stylesheet">
<!-- core - css -->
<link href="/blog/Public/Admin/js/BJUI/themes/css/style.css" rel="stylesheet">
<link href="/blog/Public/Admin/js/BJUI/themes/blue/core.css" id="bjui-link-theme" rel="stylesheet">
<!-- plug - css -->
<link href="/blog/Public/Admin/js/BJUI/plugins/kindeditor_4.1.10/themes/default/default.css" rel="stylesheet">
<link href="/blog/Public/Admin/js/BJUI/plugins/colorpicker/css/bootstrap-colorpicker.min.css" rel="stylesheet">
<link href="/blog/Public/Admin/js/BJUI/plugins/niceValidator/jquery.validator.css" rel="stylesheet">
<link href="/blog/Public/Admin/js/BJUI/plugins/bootstrapSelect/bootstrap-select.css" rel="stylesheet">
<link href="/blog/Public/Admin/js/BJUI/themes/css/FA/css/font-awesome.min.css" rel="stylesheet">
<!--[if lte IE 7]>
<link href="/blog/Public/Admin/js/BJUI/themes/css/ie7.css" rel="stylesheet">
<![endif]-->
<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lte IE 9]>
    <script src="/blog/Public/Admin/js/BJUI/other/html5shiv.min.js"></script>
    <script src="/blog/Public/Admin/js/BJUI/other/respond.min.js"></script>
<![endif]-->
<!-- jquery -->
<script src="/blog/Public/Admin/js/BJUI/js/jquery-1.7.2.min.js"></script>
<script src="/blog/Public/Admin/js/BJUI/js/jquery.cookie.js"></script>
<!--[if lte IE 9]>
<script src="/blog/Public/Admin/js/BJUI/other/jquery.iframe-transport.js"></script>    
<![endif]-->
<!-- BJUI.all 分模块压缩版 -->
<script src="/blog/Public/Admin/js/BJUI/js/bjui-all.js"></script>
<!-- 以下是B-JUI的分模块未压缩版，建议开发调试阶段使用下面的版本 -->
<!-- plugins -->
<!-- kindeditor -->
<script src="/blog/Public/Admin/js/BJUI/plugins/kindeditor_4.1.10/kindeditor-all.min.js"></script>
<script src="/blog/Public/Admin/js/BJUI/plugins/kindeditor_4.1.10/lang/zh_CN.js"></script>
<!-- ztree -->
<script src="/blog/Public/Admin/js/BJUI/plugins/ztree/jquery.ztree.all-3.5.js"></script>
<!-- bootstrap plugins -->
<script src="/blog/Public/Admin/js/BJUI/plugins/bootstrap.min.js"></script>
<script src="/blog/Public/Admin/js/BJUI/plugins/bootstrapSelect/bootstrap-select.min.js"></script>
<script src="/blog/Public/Admin/js/BJUI/plugins/bootstrapSelect/defaults-zh_CN.min.js"></script>
<!-- niceValidator -->
<script src="/blog/Public/Admin/js/BJUI/plugins/niceValidator/jquery.validator.js"></script>
<script src="/blog/Public/Admin/js/BJUI/plugins/niceValidator/jquery.validator.themes.js"></script>
<link href="/blog/Public/Admin/js/BJUI/plugins/niceValidator/jquery.validator.css" rel="stylesheet">

<!-- ajax func-->


<script type="text/javascript">

$(function() {
    BJUI.init({
        JSPATH       : '/blog/Public/Admin/js/BJUI/',         //[可选]框架路径
        PLUGINPATH   : '/blog/Public/Admin/js/BJUI/plugins/', //[可选]插件路径
        //loginInfo    : {url:'login_timeout.html', title:'登录', width:400, height:200}, // 会话超时后弹出登录对话框
        statusCode   : {ok:200, error:300, timeout:301}, //[可选] ajax回调函数的状态码
        ajaxTimeout  : 5000, //[可选]全局Ajax请求超时时间(毫秒)
        pageInfo     : {total:'total', pageCurrent:'pageCurrent', pageSize:'pageSize', orderField:'orderField', orderDirection:'orderDirection'}, //[可选]分页参数key
        alertMsg     : {displayPosition:'topcenter', displayMode:'slide', alertTimeout:3000}, //[可选]信息提示的显示位置，显隐方式，及[info/correct]方式时自动关闭延时(毫秒)
        keys         : {statusCode:'statusCode', message:'message'}, //[可选] ajax回调函数的key
        ui           : {
                         windowWidth      : 1920, //框架显示宽度，0=100%宽，> 600为则居中显示
                         showSlidebar     : true, //[可选]左侧导航栏锁定/隐藏
                         clientPaging     : true, //[可选]是否在客户端响应分页及排序参数
                         overwriteHomeTab : false //[可选]当打开一个未定义id的navtab时，是否可以覆盖主navtab(我的主页)
                       },
        debug        : true,    // [可选]调试模式 [true|false，默认false]
        theme        : ['red'] // 若有Cookie['bjui_theme'],优先选择Cookie['bjui_theme']。皮肤[六种皮肤:default, orange, purple, blue, red, green]
    })



	//菜单切换
	$(document)
	.on('click', 'ul.menu-items li > a', function(e) {
		var $a = $(this),$li = $a.parent()
		 $("ul.menu-items li").removeClass('active');
		 $("ul.menu-items li").removeClass('switch');
		 $li.addClass('active');
		 $li.addClass('switch');
		 //console.log($li.html());
	})
	.on('click', 'ul.tabsMoreList li > a', function(e) {
		var $b = $(this),$li = $b.parent(),$title = $b.attr("title")

		 if($title){
				$("ul.menu-items li").removeClass('active');
				$("ul.menu-items li").removeClass('switch');
				$("ul.menu-items li").find("a[title="+$title+"]").parent().addClass('active');
				$("ul.menu-items li").find("a[title="+$title+"]").parent().addClass('switch');

		 }else{
				$("ul.menu-items li").removeClass('active');
				$("ul.menu-items li").removeClass('switch');
				$("ul.menu-items li").eq(0).addClass('active');
				$("ul.menu-items li").eq(0).addClass('switch');
		 }
	})
	.on('click', 'ul.navtab-tab.nav.nav-tabs li > a', function(e) {
		var $c = $(this),$li = $c.parent(),$title = $c.attr("title")

		  if($title){
				$("ul.menu-items li").removeClass('active');
				$("ul.menu-items li").removeClass('switch');
				$("ul.menu-items li").find("a[title="+$title+"]").parent().addClass('active');
				$("ul.menu-items li").find("a[title="+$title+"]").parent().addClass('switch');

		 }else{
				$("ul.menu-items li").removeClass('active');
				$("ul.menu-items li").removeClass('switch');
				$("ul.menu-items li").eq(0).addClass('active');
				$("ul.menu-items li").eq(0).addClass('switch');
		 }
	})



	//时钟
    var today = new Date(), time = today.getTime()
    $('#bjui-date').html(today.formatDate('yyyy/MM/dd'))
    setInterval(function() {
        today = new Date(today.setSeconds(today.getSeconds() + 1))
        $('#bjui-clock').html(today.formatDate('HH:mm:ss'))
    }, 1000)

	
})




</script>