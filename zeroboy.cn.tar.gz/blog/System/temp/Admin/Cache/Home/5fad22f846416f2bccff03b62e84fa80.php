<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <title>xxx</title>
 </head>
 <link rel="stylesheet" type="text/css" href="/blog/Public/Admin/css/common.css">
 <script type="text/javascript" src="/blog/Public/Admin/js/jquery-1.7.2.min.js"></script>
 <body>
 <div class="bjui-pageContent">
	<!--{<?php if($CateUpdateInfo != null): ?>}-->
	<form action="<?php echo U('ArticleCategory/DoUpdate','',false);?>" data-toggle="validate" >
	<table class='table table-bordered table-striped table-hover'>
		<tr>
			<td>文章分组父级</td>
			<td>
				<select name="articlecate_parent_mark" data-toggle="selectpicker">
					<option value="0">├顶级分类</option>
					<!--{<?php if(is_array($ArticleCateList['ArticleCateList'])): foreach($ArticleCateList['ArticleCateList'] as $key=>$vo): ?>}-->
						<!--{<?php if(($vo["articlecate_id"]) == $CateUpdateInfo['pid']): ?>}-->
							<option value="<?php echo ($vo["articlecate_parent_mark"]); ?>-<?php echo ($vo["articlecate_id"]); ?>" selected>
						<!--{<?php else: ?>}-->
							<option value="<?php echo ($vo["articlecate_parent_mark"]); ?>-<?php echo ($vo["articlecate_id"]); ?>">
						<!--{<?php endif; ?>}-->
						<?php echo ($vo["html"]); echo ($vo["articlecate_name"]); ?>
						</option>
					<!--{<?php endforeach; endif; ?>}-->
				</select>
			</td>
			</tr>
			<tr>
			<td>文章分组名称</td>
			<td>
				<p><input class="form-control" name="catename" data-rule="文章分组名称:required;" placeholder="分组名称" type="text" value="<?php echo ($CateUpdateInfo['articlecate_name']); ?>"></p>

				<p style="display:none;"><input class="form-control" name="cateid" data-rule="required;" placeholder="分组名称" type="hidden" value="<?php echo ($CateUpdateInfo['articlecate_id']); ?>"></p>
			</td>
		</tr>
		<tr>
			<td colspan='2'>
				<p class="text-center"><button type="submit" class="btn btn-default">修改分组</button></p>
			</td>
		</tr>
	</table>		
	</form>
	<!--{<?php else: ?>}-->
	<form action="<?php echo U('ArticleCategory/DoAdd','',false);?>" data-toggle="validate" >
		<table class='table table-bordered table-striped table-hover'>
			<tr>
			<td>文章分组父级</td>
				<td>
					<select name="articlecate_parent_mark" data-toggle="selectpicker">
						<option value="0">├顶级分类</option>
						<!--{<?php if(is_array($ArticleCateList['ArticleCateList'])): foreach($ArticleCateList['ArticleCateList'] as $key=>$vo): ?>}-->
							<option value="<?php echo ($vo["articlecate_parent_mark"]); ?>-<?php echo ($vo["articlecate_id"]); ?>">
							<?php echo ($vo["html"]); echo ($vo["articlecate_name"]); ?>
							</option>
						<!--{<?php endforeach; endif; ?>}-->
					</select>
				</td>
				</tr>
				<tr>
					<td>文章分组名称</td>
					<td>
						<p><input class="form-control" name="catename" data-rule="文章分组名称:required;" placeholder="分组名称" type="text"></p>
					</td>
				</tr>
				<tr>
					<td colspan='2'>
						<p class="text-center"><button type="submit" class="btn btn-default">提 交</button></p>
					</td>
				</tr>
		</table>

		</form>
	<!--{<?php endif; ?>}-->
		</div>
		<div class="bjui-pageFooter">
			<ul>
				<li><button type="button" class="btn-close" data-icon="close">关闭</button></li>
			</ul>
		</div>
	</body>
</html>