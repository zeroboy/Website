<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <title>xxx</title>
 </head>
 <link rel="stylesheet" type="text/css" href="/blog/Public/Admin/css/common.css">
 <script type="text/javascript" src="/blog/Public/Admin/js/jquery-1.7.2.min.js"></script>
 <body>
 <div class="bjui-pageContent">

	<div class="smalldiv">
		<button type="button" class="btn btn-green" data-toggle="dialog" data-id="ArticleCategoryAdd" data-url="<?php echo U('Tag/AddShow','',false);?>" data-title="添加文章分组">添加标签</button>
	</div>

	<form action="<?php echo U('Tag/DoSearch','',false);?>" data-toggle="validate">
	 <table class='table table-bordered table-striped table-hover' style="margin:20px 0;">
		 <tbody>
			 <tr>
				<td>标签名称：</td>
				<td><input class="form-control" name="tagname" data-rule="标签名称:length[1~];" placeholder="标签名称" type="text" value="<?php echo ($_SESSION["condition_articletag"]["condition_tagname"]); ?>"></td>
			</tr>
			<tr>
				<td colspan=2>
				<a type="button" class="btn btn-orange" href="<?php echo U('Tag/Doclear','',false);?>" data-toggle="doajax" data-id="TagConditionClear" style="float:right;">清空查询</a>
				<button class="btn btn-orange" type="submit" style="float:right;" >搜索</button>
				</td>
			</tr>
		</tbody>
	</table>
	</form>


	<table class='table table-bordered table-striped table-hover'>
	<thead> 
		<tr>
			<th data-order-field="tag_id" >序号</th>
			<th data-order-field="tag_name">标签名称</th>
			<th colspan=2>操作</th>
		</tr>
	</thead>

	<tbody>
		<!--{<?php if($ArticleTag['ArticleTag']): ?>}-->
		<!--{<?php if(is_array($ArticleTag['ArticleTag'])): foreach($ArticleTag['ArticleTag'] as $key=>$vo): ?>}-->
		<tr>
				<td><?php echo ($vo["tag_id"]); ?></td>
				<td><?php echo ($vo["tag_name"]); ?></td>
				<td colspan=2>
				<button type="button" class="btn btn-blue" data-toggle="dialog" data-id="ArticleCategoryUpdate" data-url="<?php echo U('Tag/UpdateShow','',false);?>/id/<?php echo ($vo["tag_id"]); ?>" data-title="修改">修改</button>
				<a type="button" class="btn btn-red" href="<?php echo U('Tag/DoDelete','',false);?>/id/<?php echo ($vo["tag_id"]); ?>" data-toggle="doajax" data-confirm-msg="您确定要删除此条文章分组数据吗？" data-id="ArticleTagDelete">删除</a>
				</td>
		</tr>
		<!--{<?php endforeach; endif; ?>}-->
		<!--{<?php else: ?>}-->
		<tr>
			<td colspan=4 style="text-align:center;height:50px;">暂无数据</td>
		</tr>
		<!--{<?php endif; ?>}-->
	</tbody>
	</table>


	<!--分页-->
	<div class="bjui-pageFooter" style="background:#fff;bottom:auto;position:static;margin:10px 0;height:40px;padding-top:5px;padding-left:25%;">
			<div class="pages">
				<span>每页&nbsp;</span>
				<div class="selectPagesize">
					<select data-toggle="selectpicker" data-toggle-change="changepagesize">
						<option value="5">5</option>
						<option value="10">10</option>
						<option value="20">20</option>
						<option value="30">30</option>
						<option value="50">50</option>
						<option value="100">100</option>
					</select>
				</div>
				<span>&nbsp;条，共 <?php echo ($ArticleList['Page']['total']); ?> 条</span>
			</div>
			<div class="pagination-box pull-left" data-toggle="pagination" data-total="<?php echo ($ArticleTag['Page']['total']); ?>" data-page-size="<?php echo ($ArticleTag['Page']['size']); ?>" data-page-current="<?php echo ($ArticleTag['Page']['current']); ?>"></div>
	</div>


	<!--排序 分页-->
	<form  id="pagerForm" action="<?php echo U('Tag/DoOrder','',false);?>" >
		<input type="hidden" name="pageSize" value="<?php echo ($ArticleTag['Page']['size']); ?>"><!-- 页大小 -->
		<input type="hidden" name="pageCurrent" value="<?php echo ($ArticleTag['Page']['current']); ?>"><!-- 当前页 -->
		<input type="hidden" name="orderField" value="<?php echo I('session.ArticleTag_orderField','tag_id');?>"><!-- 排序字段 -->
		<input type="hidden" name="orderDirection" value="<?php echo I('session.ArticleTag_orderDirection','desc');?>"> <!-- 排序方向 -->
	</form>



		</div>
		<div class="bjui-pageFooter">
			<ul>
				<li><button type="button" class="btn-close" data-icon="close">关闭</button></li>
			</ul>
		</div>
	</body>
</html>