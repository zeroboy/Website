<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <title>xxx</title>
 </head>
 <link rel="stylesheet" type="text/css" href="/blog/Public/Admin/css/common.css">
 <script type="text/javascript" src="/blog/Public/Admin/js/jquery-1.7.2.min.js"></script>
 <body>
 <div class="bjui-pageContent">
	<!--{<?php if($UserInfo != null): ?>}-->
	<form  action="<?php echo U('User/DoUpdate','',false);?>" data-toggle="validate">
	<!--{<?php else: ?>}-->
	<form method="post" action="<?php echo U('User/DoAdd','',false);?>" data-toggle="validate" >
	<!--{<?php endif; ?>}-->

		<table class="table table-bordered table-striped table-hover">
		<tbody>
				<tr>
					<td>用户分组</td>
					<td>
						<select name="usercate" data-toggle="selectpicker" >
						<!--{<?php if(is_array($UserCateList)): foreach($UserCateList as $key=>$vo): ?>}-->
							<!--{<?php if(($vo["usercate_id"]) == $UserInfo['user_cate_id']): ?>}-->
								<option value="<?php echo ($vo["usercate_id"]); ?>" selected>
							<!--{<?php else: ?>}-->
								<option value="<?php echo ($vo["usercate_id"]); ?>">
							<!--{<?php endif; ?>}-->
							<?php echo ($vo["usercate_name"]); ?>
							</option>
						<!--{<?php endforeach; endif; ?>}-->
						</select>
					</td>
				</tr>
				<tr>
					<td>用户名称</td>
					<td>
						<input type="text" name="username" value="<?php echo ($UserInfo["user_account"]); ?>" data-rule="用户名称:required;length[1~];" class="form-control" >
					</td>
				</tr>
				<tr>
					<td>用户密码</td>
					<td>
						<input type="password" name="userpwd" value="" data-rule="用户密码:required;length[8~];" class="form-control" >
						<input type="hidden" name="user_id" value="<?php echo ($UserInfo["user_id"]); ?>" >
					</td>
				</tr>
				<tr>
					<td colspan='2'>
					<!--{<?php if($UserInfo != null): ?>}-->
						<p class="text-center"><button type="submit" class="btn btn-default">修改用户</button></p>
					<!--{<?php else: ?>}-->
						<p class="text-center"><button type="submit" class="btn btn-default">添加用户</button></p>
					<!--{<?php endif; ?>}-->
					</td>
				</tr>
			</tbody>
		</table>

	</form>
		</div>
		<div class="bjui-pageFooter">
			<ul>
				<li><button type="button" class="btn-close" data-icon="close">关闭</button></li>
			</ul>
		</div>
	</body>
</html>