<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <title>xxx</title>
 </head>
 <link rel="stylesheet" type="text/css" href="/blog/Public/Admin/css/common.css">
 <script type="text/javascript" src="/blog/Public/Admin/js/jquery-1.7.2.min.js"></script>
 <body>
 <div class="bjui-pageContent">
	<div class="smalldiv">
	<button type="button" class="btn btn-green" data-toggle="dialog" data-id="ArticleAdd" data-url="<?php echo U('Article/AddShow','',false);?>" data-title="添加文章分组" data-options="{width:'900',height:'450'}">添加新文章</button>
	</div>

	<!--检索-->
	<form action="<?php echo U('Article/DoSearch','',false);?>" data-toggle="validate">
	 <table class='table table-bordered table-striped table-hover' style="margin:20px 0;">
		 <tbody>
			 <tr>
				<td>文章分类：</td>
				<td>
					<select name="article_cate" data-toggle="selectpicker" >
							<option value="">请选择</option>
						<!--{<?php if(is_array($ArticleCateList)): foreach($ArticleCateList as $key=>$vo): ?>}-->
							<!--{<?php if(($vo["articlecate_id"]) == $_SESSION["condition_article"]["condition_article_cate"]): ?>}-->
								<option value="<?php echo ($vo["articlecate_id"]); ?>" selected>
							<!--{<?php else: ?>}-->
								<option value="<?php echo ($vo["articlecate_id"]); ?>">
							<!--{<?php endif; ?>}-->
							<?php echo ($vo["html"]); echo ($vo["articlecate_name"]); ?>
							</option>
						<!--{<?php endforeach; endif; ?>}-->
					</select>				
				</td>
				<td>文章标题：</td>
				<td>
					<input type="text" class="form-control" name="article_title" value="<?php echo ($_SESSION["condition_article"]["condition_article_title"]); ?>" data-rule="文章标题:length[1~];" placeholder="文章标题"  data-msg-digits="文章标题不能使用纯数字" >
				</td>
			</tr>
			<tr>
				<td >发布时间：</td>
				<td >
				<input type="text" class="form-control" data-toggle="datepicker" name="publish_time" value="<?php echo ($_SESSION["condition_article"]["condition_publish_time"]); ?>"  placeholder="发布时间" >
				</td>
				<td ></td>
				<td ></td>
			</tr>
			<tr>
				<td colspan=4>
				<a type="button" class="btn btn-orange" href="<?php echo U('Article/Doclear','',false);?>" data-toggle="doajax" data-id="ArticleConditionClear" style="float:right;">清空查询</a>
				<button class="btn btn-orange" type="submit" style="float:right;" >搜索</button>
				</td>
			</tr>
		</tbody>
	</table>
	</form>

	<!--数据-->
	<table class='table table-bordered table-striped table-hover'>
	<thead> 
		<tr>
			<th data-order-field="article_id" >序号</th>
			<th>标题</th>
			<th>作者</th>
			<th data-order-field="article_cate_id" >文章分组</th>
			<th>内容</th>
			<th data-order-field="article_create_time">创建时间</th>
			<th>是否评论</th>
			<th colspan=2>操作</th>
		</tr>
	</thead> 
	<tbody>
	<!--{<?php if($ArticleList['ArticleList']): ?>}-->
		<!--{<?php if(is_array($ArticleList['ArticleList'])): foreach($ArticleList['ArticleList'] as $key=>$vo): ?>}-->
		<tr>
				<td><?php echo ($vo["article_id"]); ?></td>
				<td><?php echo ($vo["article_title"]); ?></td>
				<td><?php echo ($vo["article_author_names"]); ?></td>
				<td><?php echo ($vo["article_cate_id"]); ?></td>
				<td><?php echo (mb_substr($vo["article_content_format"],0,20,'utf-8')); ?>...</td>
				<td><?php echo ($vo["article_create_time"]); ?></td>
				<td><?php echo ($vo["article_is_comment_c"]); ?></td>
				<td colspan=2>
				<button type="button" class="btn btn-blue" data-toggle="dialog" data-id="ArticleUpdate" data-url="<?php echo U('Article/UpdateShow','',false);?>/id/<?php echo ($vo["article_id"]); ?>" data-title="修改" data-options="{width:'900',height:'450'}">修改</button>
				<a type="button" class="btn btn-red" href="<?php echo U('Article/DoDelete','',false);?>/id/<?php echo ($vo["article_id"]); ?>" data-toggle="doajax" data-confirm-msg="您确定要删除此条文章数据吗？" data-id="ArticleDelete">删除</a>
				</td>
		</tr>
		<!--{<?php endforeach; endif; ?>}-->
	<!--{<?php else: ?>}-->
		<tr>
			<td colspan=8 style="text-align:center;height:50px;">暂无数据</td>
		</tr>
	<!--{<?php endif; ?>}-->
	</tbody>
	</table>

	<!--分页-->
	<div class="bjui-pageFooter" style="background:#fff;bottom:auto;position:static;margin:10px 0;height:40px;padding-top:5px;padding-left:20%;">
			<div class="pages">
				<span>每页&nbsp;</span>
				<div class="selectPagesize">
					<select data-toggle="selectpicker" data-toggle-change="changepagesize">
						<option value="5">5</option>
						<option value="10">10</option>
						<option value="20">20</option>
						<option value="30">30</option>
						<option value="50">50</option>
						<option value="100">100</option>
					</select>
				</div>
				<span>&nbsp;条，共 <?php echo ($ArticleList['Page']['total']); ?> 条</span>
			</div>
			<div class="pagination-box pull-left" data-toggle="pagination" data-total="<?php echo ($ArticleList['Page']['total']); ?>" data-page-size="<?php echo ($ArticleList['Page']['size']); ?>" data-page-current="<?php echo ($ArticleList['Page']['current']); ?>"></div>
	</div>

	<!--排序 分页-->
	<form  id="pagerForm" action="<?php echo U('Article/DoOrder','',false);?>" >
		<input type="hidden" name="pageSize" value="<?php echo ($ArticleList['Page']['size']); ?>"><!-- 页大小 -->
		<input type="hidden" name="pageCurrent" value="<?php echo ($ArticleList['Page']['current']); ?>"><!-- 当前页 -->
		<input type="hidden" name="orderField" value="<?php echo I('session.Article_orderField','article_id');?>"><!-- 排序字段 -->
		<input type="hidden" name="orderDirection" value="<?php echo I('session.Article_orderDirection','desc');?>"> <!-- 排序方向 -->
	</form>

		</div>
		<div class="bjui-pageFooter">
			<ul>
				<li><button type="button" class="btn-close" data-icon="close">关闭</button></li>
			</ul>
		</div>
	</body>
</html>