<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html lang="en">
 <head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
    <meta name="description" content="">
    <meta name="author" content="">
  <title>零度先生博客——致力于PHP开发</title>
 </head>
 <link rel="shortcut icon" href="/blog/Public/Home/image/favicon.jpg" type="image/x-icon" />
 <link rel="stylesheet" type="text/css" href="/blog/Public/Home/css/bootstrap.min.css">
 <link rel="stylesheet" type="text/css" href="/blog/Public/Home/css/navbar.css">
 <link rel="stylesheet" type="text/css" href="/blog/Public/Home/css/common.css">
 <script type="text/javascript" src="/blog/Public/Home/js/jquery-v11.3.js"></script>
 <script type="text/javascript" src="/blog/Public/Home/js/bootstrap.min.js"></script>
 <script type="text/javascript" src="/blog/Public/Home/js/layer1.93/layer.js"></script>
 <style type="text/css">
 /*
	body{
		background:lightblue;
	}

	div,ul,span,p,li,h1,h2,h3,h4,h5,h6,a{
		background:rgba(255,255,255,0) !important;
		color:black !important;
	}
*/
 </style>
 <body>
<style type="text/css">
	.blog-sidebar div{
		margin-bottom:30px;
	}
	.bbc{
		border:1px solid #fff;padding:10px 10px;background:#fff;border-radius:6px;
	}
	.bbc ul li{
		margin-right:10px;
	}

	.logo{
		background: #ffffff;
		background: -moz-linear-gradient(top,#ffffff 0%, #ccc 100%);
		background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#ffffff), color-stop(100%,#ccc));
		background: -webkit-linear-gradient(top,  #ffffff 0%,#ccc 100%);
		background: -o-linear-gradient(top,  #ffffff 0%,#ccc 100%);
		background: -ms-linear-gradient(top,  #ffffff 0%,#ccc 100%);
		background: linear-gradient(to bottom, #ffffff  0%,#ccc 100%);
		filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ffffff', endColorstr='#ccc',GradientType=0 );
	}

</style>

    <div class="container" >

<!---->
		 <div class="sidebar-module " > 
			<div class="panel panel-default logo" >
				<div class="panel-body">
					<div style="width:70%;">
						<img src="/blog/Public/Home/image/logo.png" style="width:150%;height:150%;max-width:700px;" border="0" alt="">
					</div>
				</div>
			</div>
		  </div>



		<!--//导航-->
		<div id="" class="bbc" >
			<ul class="nav nav-pills ">
			
			<!--{<?php if($_GET['cate']== null): ?>}-->
				<!--{<?php if(($ArticleInfo['article_cate_id'] != null) || ($Think.CONTROLLER_NAME==Aboutus)): ?>}-->
					<li role="presentation" ><a href="<?php echo U('Index/index','',false);?>">首页</a></li>
				<!--{<?php else: ?>}-->
					<li role="presentation" class="active "><a href="<?php echo U('Index/index','',false);?>">首页</a></li>
				<!--{<?php endif; ?>}-->
			<!--{<?php else: ?>}-->	
				<li role="presentation"><a href="<?php echo U('Index/index','',false);?>">首页</a></li>
			<!--{<?php endif; ?>}-->
			  <!--{<?php if(is_array($nav)): foreach($nav as $k=>$vo): ?>}-->
				  <!--{<?php if($vo["child"] ): ?>}-->
				  <!--{<?php if(($vo["articlecate_name"]) == $_GET['cate']): ?>}-->
							<li role="presentation" class="dropdown active" >
				  <!--{<?php else: ?>}-->
							<!--{<?php if(in_array(($_GET['cate']), is_array($vo["child"])?$vo["child"]:explode(',',$vo["child"]))): ?>}-->
								<li role="presentation" class="dropdown active" >
							<!--{<?php else: ?>}-->
								<!--{<?php if(in_array(($ArticleInfo['article_cate_id']), is_array($vo["child"])?$vo["child"]:explode(',',$vo["child"]))): ?>}-->
									<li role="presentation" class="dropdown active" >
								<!--{<?php else: ?>}-->
									
									<!--{<?php if(($vo["articlecate_name"]) == $ArticleInfo['article_cate_id']): ?>}-->
										<li role="presentation" class="dropdown active" >
									<!--{<?php else: ?>}-->
										<li role="presentation" class="dropdown " >
									<!--{<?php endif; ?>}-->

								<!--{<?php endif; ?>}-->
							<!--{<?php endif; ?>}-->
				  <!--{<?php endif; ?>}-->
							 <a class="dropdown-toggle" data-toggle="dropdown" href="" role="button" aria-haspopup="true" aria-expanded="false">
							  <?php echo ($vo["articlecate_name"]); ?> <span class="caret"></span>
							</a>
							<ul class="dropdown-menu">
									<li role="presentation"><a href="<?php echo U('Index/index/cate','',false);?>/<?php echo ($vo["articlecate_name"]); ?>"><?php echo ($vo["articlecate_name"]); ?></a></li>
							<!--{<?php if(is_array($vo["child"])): foreach($vo["child"] as $k1=>$vo1): ?>}-->
									<li role="presentation"><a href="<?php echo U('Index/index/cate','',false);?>/<?php echo ($vo1); ?>"><?php echo ($vo1); ?></a></li>
							<!--{<?php endforeach; endif; ?>}-->
							</ul>
						  </li>				
				  <!--{<?php else: ?>}-->
					  <!--{<?php if(($vo["articlecate_name"]) == $_GET['cate']): ?>}-->
									<li role="presentation" class="active ">
					  <!--{<?php else: ?>}-->
					    <!--{<?php if(($vo["articlecate_name"]) == $ArticleInfo['article_cate_id']): ?>}-->
									<li role="presentation" class="active ">
						<!--{<?php else: ?>}-->
									<li role="presentation" >
						<!--{<?php endif; ?>}-->
					  <!--{<?php endif; ?>}-->
									<a href="<?php echo U('Index/index/cate','',false);?>/<?php echo ($vo["articlecate_name"]); ?>"><?php echo ($vo["articlecate_name"]); ?></a></li>
					  
				  <!--{<?php endif; ?>}-->
			  <!--{<?php endforeach; endif; ?>}-->
			  <!--{<?php if(($Think.CONTROLLER_NAME==Aboutus)): ?>}-->
				<li role="presentation" class="active"><a href="<?php echo U('aboutus/index','',false);?>">关于我们</a></li>
			  <!--{<?php else: ?>}-->
				<li role="presentation" ><a href="<?php echo U('aboutus/index','',false);?>">关于我们</a></li>
			  <!--{<?php endif; ?>}-->
			</ul>
		</div>
<hr>

<script type="text/javascript">

$(function(){	
	var windowwidth = $(window).width();
	if(windowwidth<750){
		//console.log($(window).width());
		$(".nav").addClass("nav-stacked");	
	}else{
		$(".nav").removeClass("nav-stacked");
	}

});


</script>
<style type="text/css">
	.blog-main{
		padding-right:20px;
	}
	.text-justify{
		padding-top:10px;
	}
	#articlerow{
		-moz-box-shadow: 3px 3px 4px #aaaaaa; /* 老的 Firefox */
		box-shadow:3px 3px 4px #aaaaaa;
		margin-bottom:40px;
	}
</style>
		<div class="row" >
			<div class="col-sm-9 blog-main">
			
					<!--//板块-->
					<!--{<?php if($articlelist != null): ?>}-->
					<?php echo ($articlelist); ?>
					<!--{<?php else: ?>}-->
						<div class="panel panel-default">
						  <div class="panel-body">
							<h3>暂无文章</h3>
						  </div>
						</div>
					<!--{<?php endif; ?>}-->
					<!--//板块-->

			</div>
			<div class="col-sm-3 ">
					   <link rel="stylesheet" type="text/css" href="/blog/Public/Home/css/jqcloud.css" />
    <script type="text/javascript" src="/blog/Public/Home/js/jqcloud-1.0.4.js"></script>
	<style>
	/*置顶*/
	.back-to {bottom: 35px;overflow:hidden;position:fixed;right:10px;width:50px;z-index:999;}
	.back-to .back-top {background: url("/blog/Public/Home/image/top.png") no-repeat scroll 0 0 transparent;display: block;float: right;height:50px;margin-left: 10px;outline: 0 none;text-indent: -9999em;width: 50px;}
	.back-to .back-top:hover {background-position: -50px 0;}

	.right-style{
		-moz-box-shadow: 3px 3px 4px #aaaaaa; /* 老的 Firefox */
		box-shadow:3px 3px 4px #aaaaaa;
	}
	</style>

  <div class="sidebar-module sidebar-module-inset" >
	  <div class="panel panel-default">
		<div class="panel-body right-style">
		<h4>关于本站</h4>
		<p>本站致力于PHP及相关语言的开发与传播、分享、研究、讨论。</p>
		</div>
	  </div>
  </div>

<div class="sidebar-module" > 
	<div class="panel panel-default">
		<div class="panel-body right-style">
			<h4>文章归档</h4>

			<div class="list-group">

			<!--{<?php if(is_array($archiving)): foreach($archiving as $k=>$vo): ?>}-->
			 <!--{<?php if(($vo["pubtime"]) == $_GET['date']): ?>}-->
			  <a href="<?php echo U('Index/index/date','',false);?>/<?php echo ($vo["pubtime"]); ?>" class="list-group-item active" ><?php echo ($vo["pubtime_format"]); ?><span class="badge"><?php echo ($vo["cnt"]); ?></span></a>
			<!--{<?php else: ?>}-->
			  <a href="<?php echo U('Index/index/date','',false);?>/<?php echo ($vo["pubtime"]); ?>" class="list-group-item" ><?php echo ($vo["pubtime_format"]); ?><span class="badge"><?php echo ($vo["cnt"]); ?></span></a>
			<!--{<?php endif; ?>}-->
			<!--{<?php endforeach; endif; ?>}-->
			</div>

		</div>
	</div>
  </div>

  <div class="sidebar-module" > 
	<div class="panel panel-default">
		<div class="panel-body right-style">
			<h4>近期文章</h4>
			<!--{<?php if(is_array($recentarticle)): foreach($recentarticle as $k=>$vo): ?>}-->
				<a class="list-group-item" href="<?php echo U('Article/index','',false);?>/id/<?php echo ($vo["article_id"]); ?>"><?php echo ($vo["article_title_format"]); ?></a>
			<!--{<?php endforeach; endif; ?>}-->
		</div>
	</div>
  </div>

   <div class="sidebar-module" > 
	<div class="panel panel-default">
		<div class="panel-body right-style">
			<h4>热评文章</h4>
			<!--{<?php if(is_array($hotcomment)): foreach($hotcomment as $k=>$vo): ?>}-->
			<!--{<?php if($k == 0): ?>}-->
				<a class="list-group-item list-group-item-danger" href="<?php echo ($vo["url"]); ?>">
			<!--{<?php elseif( $k == 1): ?>}-->
				<a class="list-group-item list-group-item-warning" href="<?php echo ($vo["url"]); ?>">
			<!--{<?php elseif($k == 2): ?>}-->
				<a class="list-group-item list-group-item-info" href="<?php echo ($vo["url"]); ?>">
			<!--{<?php else: ?>}-->
				<a class="list-group-item list-group-item-success" href="<?php echo ($vo["url"]); ?>">
			<!--{<?php endif; ?>}-->
				<img src="/blog/Public/Home/image/numbers/<?php echo ($k+1); ?>.png" style="width:15px;height:15px;" >&nbsp;&nbsp;<?php echo ($vo["title"]); ?><span class="badge"><?php echo ($vo["comments"]); ?></span></a>
			<!--{<?php endforeach; endif; ?>}-->
		</div>
	</div>
  </div>

<!--
   <div class="sidebar-module" > 
	<div class="panel panel-default">
		<div class="panel-body">
			<h4>热评文章</h4>

				<!-- 多说热评文章 start 
				<div class="ds-top-threads" data-range="monthly" data-num-items="5"></div>
			<!-- 多说热评文章 end
			<!-- 多说公共JS代码 start (一个网页只需插入一次)
			<script type="text/javascript">
			var duoshuoQuery = {short_name:"zeroboy"};
				(function() {
					var ds = document.createElement('script');
					ds.type = 'text/javascript';ds.async = true;
					ds.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') + '//static.duoshuo.com/embed.js';
					ds.charset = 'UTF-8';
					(document.getElementsByTagName('head')[0] 
					 || document.getElementsByTagName('body')[0]).appendChild(ds);
				})();
				</script>
			<!-- 多说公共JS代码 end 

		</div>
	</div>
  </div>
-->

  <div class="sidebar-module" > 
	<div class="panel panel-default">
		<div class="panel-body right-style">
			<h4>近期评论</h4>
			<ul class="list-group">
			<!--{<?php if(is_array($recentcomment)): foreach($recentcomment as $k=>$vo): ?>}-->

					<a class="list-group-item" href=""><img src="<?php echo ($vo["author_img"]); ?>" class="img-thumbnail" style="width: 40px;"><strong><?php echo ($vo["author_name"]); ?></strong>:<?php echo ($vo["content"]); ?></a>

			<!--{<?php endforeach; endif; ?>}-->
			</ul>
		</div>
	</div>
  </div>

  <div class="sidebar-module" > 
	<div class="panel panel-default">
		<div class="panel-body right-style">
			<h4>标签云</h4>
			<div id="example" style="width:auto; height: 300px;"></div>
		</div>
	</div>
  </div>
<!--
  <div class="sidebar-module">
	<div class="panel panel-default">
		<div class="panel-body right-style">
			<h4>其他</h4>
			<ol class="list-unstyled">
			  <li><a href="#">推荐</a></li>
			  <li><a href="#">分享</a></li>
			</ol>
		</div>
	</div>
  </div>-->
  
	<!--//置顶-->
	<div style="display:none;" class="back-to" id="toolBackTop">
		<a title="返回顶部" onclick="window.scrollTo(0,0);return false;" href="#top" class="back-top">
			返回顶部
		</a>
	</div>

  <script type="text/javascript">

      /*!
       * Create an array of word objects, each representing a word in the cloud
       */
      var word_array = eval("("+'<?php echo ($tagcloud); ?>'+")");
	//console.log(word_array);
      $(function() {
        // When DOM is ready, select the container element and call the jQCloud method, passing the array of words as the first argument.
        $("#example").jQCloud(word_array,{
		
			'shape':'rectangular',//形状
			removeOverflowing: true,//自动

		});
      });


	$(document).ready(function () {
			var bt = $('#toolBackTop');
			var sw = $(document.body)[0].clientWidth;

			var limitsw = (sw - 1060) / 2 - 40;
			if (limitsw > 0){
					limitsw = parseInt(limitsw);
					bt.css("right",limitsw);
			}

			$(window).scroll(function() {
					var st = $(window).scrollTop();
					if(st > 30){
							bt.fadeIn("fast");
					}else{
							bt.fadeOut("fast");
					}
			});
	})


  </script>						
			</div>
		</div>

		
		<div class="row" >
			<div class="col-sm-12 " >
				<div class="panel panel-default" style="background:rgba(85,85,85,0.1);margin:20px 0;">
				  <div class="panel-body" style="padding:30px 0;">
						<p class="footer-title" style='font-size:11px;text-align:center;color:rgb(150,150,150);'>© 零度先生 All rights reserved <a href='http://beian.cndns.com/' target="_blank">&nbsp;&nbsp;京ICP备15041727号-1</a> &nbsp;&nbsp;&nbsp;&nbsp;<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1256043746'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s95.cnzz.com/z_stat.php%3Fid%3D1256043746%26show%3Dpic' type='text/javascript'%3E%3C/script%3E"));</script></p>
				  </div>
				</div>

			</div>
		</div>

		</div><!-- /.container -->
	</body>
</html>

<script type="text/javascript">


$(window).scroll(function() {
		if ($(document).scrollTop() >= $(document).height() - $(window).height()) {

			var total = $(".blog-main").find("div[id=articlerow]").length;
			var allpage = parseInt(total/10);
			var curr = allpage+1;
			var cate = "<?php echo ($_GET['cate']); ?>";
			var tag = "<?php echo ($_GET['tag']); ?>";
			var date = "<?php echo ($_GET['date']); ?>";			if("<?php echo (CONTROLLER_NAME); ?>" == 'aboutus'){				return;			}
			//return;
			if(total%10 == 0){

					$.ajax({
					   type: "POST",
					   url: '<?php echo U("Index/ArticleList","",false);?>',
					   data: { 
								curr : curr,
								cate : cate,
								tag  : tag,
								date : date,
							},
					   beforeSend : function(xhr, settings) {
							var index = layer.load(1, {
							shade: [0.4,'#fff'], 
							});
						},
					   success: function(data){
							//console.log(data);
							//return;
							if(data.status >0) {
								
								$(".blog-main").append(data.content);

							}else{
								layer.alert(data.msg, { icon: 2});
							}
					   },
						error : function(XMLHttpRequest, textStatus, errorThrown) {
						
						},
						complete : function() {
							layer.closeAll('loading');
						}
					},"json");

			}else{
					
				//layer.alert("已加载到最后一页", { icon: 2});
			}
		}
});

$(function(){	
	var windowwidth = $(window).width();
	if(windowwidth<750){
		console.log($(window).width());
		$(".blog-main").css("padding-right","20px");	
	}else{
		$(".blog-main").css("padding-right","60px");
	}

});

</script>